<?php
function promjena_vrste($korisnik_id, $tip_korisnika_id){
  $sqlupdate = "UPDATE korisnik SET tip_korisnika_id = '" . $tip_korisnika_id . "' WHERE korisnik_id = '" . $korisnik_id . "'";
  $sqlresult = izvrsiUpit($sqlupdate);

  echo "Vrsta korisnika promjenjena!";
}

function promjenaKorisnicko($vrijednost, $korisnik_id){

  $sqlupdate = "UPDATE korisnik SET korisnicko_ime = '" . $vrijednost . "' WHERE korisnik_id = '" . $korisnik_id . "'";
  $sqlresult = izvrsiUpit($sqlupdate);

  echo "Korisnicko ime promjenjeno!";

}


function promjenaIme($vrijednost, $korisnik_id){

  $sqlupdate = "UPDATE korisnik SET ime = '" . $vrijednost . "' WHERE korisnik_id = '" . $korisnik_id . "'";
  $sqlresult = izvrsiUpit($sqlupdate);

  echo "Ime promjenjeno!";

  

}


function promjenaPrezime($vrijednost, $korisnik_id){

  $sqlupdate = "UPDATE korisnik SET prezime = '" . $vrijednost . "' WHERE korisnik_id = '" . $korisnik_id . "'";
  $sqlresult = izvrsiUpit($sqlupdate);

  echo "Prezime promjenjeno!";


}

function promjenaEmail($vrijednost, $korisnik_id){

  $sqlupdate = "UPDATE korisnik SET email = '" . $vrijednost . "' WHERE korisnik_id = '" . $korisnik_id . "'";
  $sqlresult = izvrsiUpit($sqlupdate);

  echo "Email promjenjen!";

}



if (isset($_POST['submit'])) {
  if(isset($_GET['promjena_vrste_admin'])){
    promjena_vrste($_GET['promjena_vrste_admin'], $_POST['vrsta']);
  }elseif(isset($_GET['promjena_podataka'])){

    $vrsta_promjene = $_GET['promjena_podataka'];

    if($vrsta_promjene === "korIme"){

      $vrijednost = $_POST['korisnicko'];
      $korisnik_id = $_GET['korisnik_id'];

      promjenaKorisnicko($vrijednost, $korisnik_id);

    }elseif($vrsta_promjene === "ime"){

      $vrijednost = $_POST['ime'];
      $korisnik_id = $_GET['korisnik_id'];

      promjenaIme($vrijednost, $korisnik_id);
    
    }elseif($vrsta_promjene === "prezime"){

      $vrijednost = $_POST['prezime'];
      $korisnik_id = $_GET['korisnik_id'];

      promjenaPrezime($vrijednost, $korisnik_id);
    
    }elseif($vrsta_promjene === "email"){

      $vrijednost = $_POST['email'];
      $korisnik_id = $_GET['korisnik_id'];

      promjenaEmail($vrijednost, $korisnik_id);
    
    }

  }
}

?>