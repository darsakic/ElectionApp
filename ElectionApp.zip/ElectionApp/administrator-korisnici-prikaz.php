<?php
$sqlkorisnici = "SELECT * FROM korisnik";
$sqlresult = izvrsiUpit($sqlkorisnici);


if(isset($_GET['promjena_podataka'])){
    $vrsta_promjene = $_GET['promjena_podataka'];

    if($vrsta_promjene === "korIme"){

        echo '<form class="form" method="post" action="">';

        echo '<label for="korisnicko">Novo korisnicko ime: </label>';
        echo '<input type="text" class="korisnicko" name="korisnicko" id="korisnicko">';

        echo '<input type="submit" class="submit" id="submit" name="submit" value="Promjeni korisnicko ime">';

        echo '</form>';

    }elseif ($vrsta_promjene === "ime") {

        echo '<form class="form" method="post" action="">';

        echo '<label for="ime">Novo ime: </label>';
        echo '<input type="text" class="ime" name="ime" id="ime">';

        echo '<input type="submit" class="submit" id="submit" name="submit" value="Promjeni ime">';

        echo '</form>';
        
    }elseif ($vrsta_promjene === "prezime") {

        echo '<form class="form" method="post" action="">';

        echo '<label for="prezime">Novo prezime: </label>';
        echo '<input type="text" class="prezime" name="prezime" id="prezime">';

        echo '<input type="submit" class="submit" id="submit" name="submit" value="Promjeni prezime">';

        echo '</form>';
        
    }elseif ($vrsta_promjene === "email") {
        
        echo '<form class="form" method="post" action="">';

        echo '<label for="email">Novi email: </label>';
        echo '<input type="text" class="email" name="email" id="email">';

        echo '<input type="submit" class="submit" id="submit" name="submit" value="Promjeni email">';

        echo '</form>';

    }
}

echo "<table class='aktivni-izbori'>";
echo "<h2>Popis korisnika</h2>";
echo "<th>Korisnicko ime</th>";
echo "<th>Ime</th>";
echo "<th>Prezime</th>";
echo "<th>Email</th>";
echo "<th>Tip</th>";

if (isset($_GET['promjena_vrste_admin'])) {
    echo "<td>";
    echo "<form class='form' method='post' action=''>";
    echo "<select name='vrsta'>";
    echo "<option value='1'>Administrator</option>";
    echo "<option value='2'>Moderator</option>";
    echo "<option value='3'>Obični korisnik</option>";
    echo "</select>";
    echo "</td>";
    echo "<td><input type='submit' class='submit' id='submit' name='submit' value='Potvrdi'></td>";
    echo "</form>";
    echo "</td>";
}elseif (isset($_GET['promjena_vrste_moderator'])) {
    echo "<td>";
    echo "<form class='form' method='post' action=''>";
    echo "<select name='vrsta'>";
    echo "<option value='2'>Moderator</option>";
    echo "<option value='1'>Administrator</option>";
    echo "<option value='3'>Obični korisnik</option>";
    echo "</select>";
    echo "</td>";
    echo "<td><input type='submit' class='submit' id='submit' name='submit' value='Potvrdi'></td>";
    echo "</form>";
    echo "</td>";
}elseif(isset($_GET['promjena_vrste_registrirani'])){
    echo "<td>";
    echo "<form class='form' method='post' action=''>";
    echo "<select name='vrsta'>";
    echo "<option value='3'>Obični korisnik</option>";
    echo "<option value='2'>Moderator</option>";
    echo "<option value='1'>Administrator</option>";
    echo "</select>";
    echo "</td>";
    echo "<td><input type='submit' class='submit' id='submit' name='submit' value='Potvrdi'></td>";
    echo "</form>";
    echo "</td>";
}



while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $korisnici = array();
    $korisnici[] = $row;

    foreach ($korisnici as $data) {

        echo "<tr>";
        echo "<td><a href='administrator-home.php?promjena_podataka=korIme&korisnik_id=" . $data['korisnik_id'] . "'>" . $data['korisnicko_ime'] . "</a></td>";
        echo "<td><a href='administrator-home.php?promjena_podataka=ime&korisnik_id=" . $data['korisnik_id'] . "'>" . $data['ime'] . "</a></td>";
        echo "<td><a href='administrator-home.php?promjena_podataka=prezime&korisnik_id=" . $data['korisnik_id'] . "'>" . $data['prezime'] . "</a></td>";
        echo "<td><a href='administrator-home.php?promjena_podataka=email&korisnik_id=" . $data['korisnik_id'] . "'>" . $data['email'] . "</a></td>";

        if ($data['tip_korisnika_id'] === '1') {
            echo "<td><a href='administrator-home.php?promjena_vrste_admin=" . $data['korisnik_id'] . "'>Administrator</a></td>";
        } elseif ($data['tip_korisnika_id'] === '2') {
            echo "<td><a href='administrator-home.php?promjena_vrste_moderator=" . $data['korisnik_id'] . "'>Moderator</a></td>";
        } else {
            echo "<td><a href='administrator-home.php?promjena_vrste_registrirani=" . $data['korisnik_id'] . "'>Registrirani korisnik</a></td>";
        }
    }
}

echo "</table>";

include "administrator-korisnici-promjeni-vrstu.php";

