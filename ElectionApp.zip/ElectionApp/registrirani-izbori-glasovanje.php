<?php

function davanje_glasa($korisnik_id, $kandidat_id)
{
    $sqlglas = "SELECT * FROM glas WHERE korisnik_id = '" . $korisnik_id . "' AND kandidat_id = '" . $kandidat_id . "'";
    $sqlresult = izvrsiUpit($sqlglas);

    if (mysqli_num_rows($sqlresult) > 0) {
        echo "Ne možete više glasati na ovim izborima!";
    } else {
        $sqlinsert = "INSERT INTO glas (korisnik_id, kandidat_id) VALUES ('" . $korisnik_id . "', '" . $kandidat_id . "')";
        $sqlresult_insert = izvrsiUpit($sqlinsert);

        echo "Uspješno ste dali vaš glas na izborima!";
    }
}

if (isset($_GET['korisnik_id']) && isset($_GET['kandidat_id'])) {
    davanje_glasa($_GET['korisnik_id'], $_GET['kandidat_id']);
}
