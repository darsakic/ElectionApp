<?php

$sqlkandidatura = "SELECT k.ime, k.prezime, i.naziv, i.opis, t.izbor_id FROM korisnik k, kandidat t, izbor i WHERE k.korisnik_id = t.korisnik_id AND t.izbor_id = i.izbor_id AND i.datum_vrijeme_zavrsetka > CURRENT_TIMESTAMP() AND t.status<>'O' AND t.korisnik_id = '" . $_SESSION['id_korisnika'] . "'";
$sqlresult = izvrsiUpit($sqlkandidatura);

echo "<table>";
echo "<h2>Kandidature</h2>";
echo "<th>Ime</th>";
echo "<th>Prezime</th>";
echo "<th>Naziv</th>";
echo "<th>Opis</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $kandidatura = array();
    $kandidatura[] = $row;

    foreach ($kandidatura as $data) {

        echo "<tr>";
        echo "<td>" . $data['ime'] . "</td>";
        echo "<td>" . $data['prezime'] . "</td>";
        echo "<td>" . $data['naziv'] . "</td>";
        echo "<td>" . $data['opis'] . "</td>";
        echo "<td><a href='registrirani-home.php?korisnik_povlacenje_id=" . $_SESSION['id_korisnika'] . "&izbor_id=" . $data['izbor_id'] . "'>Povuci se</a></td>";
        echo "</tr>";

    }
}

echo "</table>";


