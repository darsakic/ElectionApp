<?php

function prikaz_pobjednika($izbor_id)
{
    $sqlpobjednik = "SELECT * FROM korisnik k, kandidat t WHERE k.korisnik_id=t.korisnik_id AND t.izbor_id = '" . $izbor_id . "' AND t.status = 'P'";
    $sqlresult = izvrsiUpit($sqlpobjednik);

    echo "<table>";
    echo "<th>Ime</th>";
    echo "<th>Prezime</th>";
    echo "<th>Email</th>";
    echo "<th>Životopis</th>";
    echo "<th>Slika</th>";
    echo "<th>Video</th>";


    while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
      $pobjednik = array();
      $pobjednik[] = $row;

      foreach ($pobjednik as $data) {

        echo "<tr>";
        echo "<td>" . $data['ime'] . "</td>";
        echo "<td>" . $data['prezime'] . "</td>";
        echo "<td>" . $data['email'] . "</td>";
        echo "<td>" . $data['zivotopis'] . "</td>";
        echo "<td> <img src=" . $data['slika'] . "> </td>";
        echo "<td> <video width='320' height='240' controls src='" . $data['video'] . "'></video></td>";
        echo "</tr>";

      }
  }
}

if (isset($_GET['izborno_mjesto']) && isset($_GET['izbor_id'])) {
    prikaz_pobjednika($_GET['izbor_id']);
}
