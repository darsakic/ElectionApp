<?php
$sqlizbori = "SELECT * FROM izbor";
$sqlresult = izvrsiUpit($sqlizbori);

echo "<table class='aktivni-izbori'>";
echo "<h2>Izbori</h2>";
echo "<th>Naziv</th>";
echo "<th>Datum i vrijeme pocetka</th>";
echo "<th>Datum i vrijeme zavrsetka</th>";
echo "<th>Opis</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $izbori = array();
    $izbori[] = $row;

    foreach ($izbori as $data) {

        echo "<tr>";
        echo "<td>" . $data['naziv'] . "</td>";
        echo "<td>" . str_replace("-", ".", $data['datum_vrijeme_pocetka']) . "</td>";
        echo "<td>" . str_replace("-", ".", $data['datum_vrijeme_zavrsetka']) . "</td>";
        echo "<td>" . $data['opis'] . "</td>";

    }
}


echo "</table>";
