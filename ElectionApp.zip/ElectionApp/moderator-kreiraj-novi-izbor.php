<?php

function kreiranje_izbora($izborno_mjesto_id, $naziv, $datum_pocetka, $opis)
{
    if (preg_match("/^([1-9]|([012][0-9])|(3[01])).([0]{0,1}[1-9]|1[012]).\d\d\d\d [012]{0,1}[0-9]:[0-6][0-9]:[0-6][0-9]$/", $datum_pocetka)) {
        $datumPocetakTime = (strtotime($datum_pocetka));
        $datumPocetakPretvori = date('Y-m-d H:i:s', $datumPocetakTime);
        $datumZavrsetkaTime = (strtotime($datum_pocetka) + 86400 * 7);
        $datumZavrsetakPretvori = date('Y-m-d H:i:s', $datumZavrsetkaTime);

        $sqlizbor = "INSERT INTO izbor (izbor_id, izborno_mjesto_id, naziv, datum_vrijeme_pocetka, datum_vrijeme_zavrsetka, opis) VALUES (default, '" . $izborno_mjesto_id . "', '" . $naziv . "', '" . $datumPocetakPretvori . "', '" . $datumZavrsetakPretvori . "', '" . $opis . "')";
        $sqlresult = izvrsiUpit($sqlizbor);


        if($sqlresult == true){
            echo "Novi izbori kreirani, preusmjeravamo na izborna mjesta!";
            header('Refresh: 1; URL=moderator-home.php');
        }

    } else {
        echo "Neispravan format datuma!";
    }
}

if (isset($_POST['submit'])) {
    kreiranje_izbora($_GET['izborno_mjesto_id'], $_POST['naziv'], $_POST['pocetak'], $_POST['opis']);
}