<?php

    function izvrsiUpit($upit){
        $konekcija = mysqli_connect("localhost", "iwa_2017", "foi2017", "iwa_2017_vz_projekt");
        mysqli_set_charset($konekcija, "utf8");
        $vraceno = mysqli_query($konekcija, $upit);
        mysqli_close($konekcija);
        return $vraceno;
    }

?>