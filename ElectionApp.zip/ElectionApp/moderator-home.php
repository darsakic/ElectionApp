<?php

session_start();

include_once 'baza.php';

if (!isset($_SESSION['prijavljen'])) {
    header("Location: prijava.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="style.css">
  <title>Moderator: Home</title>
</head>
<body>

<header>
<nav>

<?php
  include 'navigacija.php';
?>
</nav>

</header>

<main>

<?php

include "moderator-prikazi-izbore.php";
include "moderator-prikazi-kandidate.php";
include "moderator-forma-za-azuriranje.php";

if (isset($_GET['izbor_id_pobijedio'])) {
    include "moderator-izaberi-pobjednika.php";
    
    odabir_pobjednika($_GET['izbor_id_pobijedio']);
}

?>

</main>

</body>
</html>
