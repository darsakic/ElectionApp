<?php

if (isset($_GET['korisnik_povlacenje_id']) && isset($_GET['izbor_id'])) {

    $sqlupdate = "UPDATE kandidat SET status = 'O' WHERE korisnik_id = '" . $_GET['korisnik_povlacenje_id'] . "' AND izbor_id = '" . $_GET['izbor_id'] . "'";
    $sqlresult = izvrsiUpit($sqlupdate);

    echo "Povukli ste se sa izbora!";
    echo " ";
    echo "Za 2 sec će te biti preusmjereni nazad...";
    header('Refresh: 2; URL=prijava.php');
}
