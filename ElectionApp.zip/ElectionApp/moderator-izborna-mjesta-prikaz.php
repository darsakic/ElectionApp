<?php
$sqlmjesta = "SELECT * FROM izborno_mjesto WHERE moderator_id = '" . $_SESSION['id_korisnika'] . "' ";
$sqlresult = izvrsiUpit($sqlmjesta);

echo "<table >";
echo "<h2>Izborna mjesta</h2>";
echo "<th>Naziv</th>";
echo "<th>Opis</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
  $izbornomjesto = array();
  $izbornomjesto[] = $row;

  foreach ($izbornomjesto as $data) {

    echo "<tr>";
    echo "<td>" . $data['naziv'] . "</td>";
    echo "<td>" . $data['opis'] . "</td>";
    echo "<td><a href='moderator-izborna-mjesta.php?izborno_mjesto_id=" . $data['izborno_mjesto_id'] . "'>Novi izbor</a></td>";
    echo "</tr>";
  }
}

echo "</table>";
