<?php

include_once 'baza.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="style.css">
  <title>Document</title>
</head>
<body>

<form class="novo-izborno-mjesto" method="post" action="">

    <label for="naziv">Naziv: </label>
    <input type="text" class="naziv" name="naziv" id="naziv">

    <label for="opis">Opis: </label>
    <textarea name="opis" id="opis" cols="40" rows="5"></textarea>

    <label for="moderator">Moderator: </label>
    <?php
    
    $sqlselect = "SELECT * FROM korisnik WHERE tip_korisnika_id LIKE '2' ";
    $sqlresult = izvrsiUpit($sqlselect);

    echo "<select name='moderator'>";


    while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
      $korisnici = array();
      $korisnici[] = $row;

      foreach ($korisnici as $data) {

        echo "<option value='" . $data['korisnik_id'] . "'>" . $data['korisnicko_ime'] . "</option>";

      }
  }

  echo "</select>";

    
    ?>

    <input type="submit" class="submit" id="submit" name="submit" value="Kreiraj">
</form>


<?php

if(isset($_POST['submit'])){
  $naziv = $_POST['naziv'];
  $opis = $_POST['opis'];
  $moderator = $_POST['moderator'];
  
  $sqlinsert = "INSERT INTO izborno_mjesto(izborno_mjesto_id, moderator_id, naziv, opis) VALUES (default, '" . $moderator . "', '" . $naziv . "', '" . $opis . "')";
  $sqlresult = izvrsiUpit($sqlinsert);

  if($sqlresult == true){
    echo "Uspješno kreirano novo izborno mjesto, preusmjeravamo vas na izborna mjesta...";
    header('Refresh: 1; URL=administrator-izborna-mjesta.php');
  }
}

?>
  
</body>
</html>