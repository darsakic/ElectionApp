<?php

function prikaz_zavrsenih_izbora($izborno_mjesto_id)
{

    $sqlzavrseni = "SELECT * FROM izborno_mjesto i, izbor r WHERE i.izborno_mjesto_id = r.izborno_mjesto_id AND i.izborno_mjesto_id = $izborno_mjesto_id AND r.datum_vrijeme_zavrsetka < CURRENT_TIMESTAMP() ORDER BY r.datum_vrijeme_zavrsetka DESC;";
    $sqlresult = izvrsiUpit($sqlzavrseni);

    echo "<table>";
    echo "<th>Naziv</th>";
    echo "<th>Datum i vrijeme pocetka</th>";
    echo "<th>Datum i vrijeme zavrsetka</th>";
    echo "<th>Opis</th>";

    while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
        $zavrseni = array();
        $zavrseni[] = $row;

        foreach ($zavrseni as $data) {

          echo "<tr>";
          echo "<td>" . $data['naziv'] . "</td>";
          echo "<td>" . str_replace("-", ".", $data['datum_vrijeme_pocetka']) . "</td>";
          echo "<td>" . str_replace("-", ".", $data['datum_vrijeme_zavrsetka']) . "</td>";
          echo "<td>" . $data['opis'] . "</td>";
          echo "<td><a href='index.php?izborno_mjesto=" . $izborno_mjesto_id . "&izbor_id=" . $data['izbor_id'] . "'>Pobjednik izbora</a></td>";
          echo "</tr>";

        }
    }

    echo "</table>";

}

if (isset($_GET['izborno_mjesto_id'])) {
  prikaz_zavrsenih_izbora($_GET['izborno_mjesto_id']);
}