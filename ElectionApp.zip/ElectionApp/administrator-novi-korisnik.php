<?php

session_start();

include_once 'baza.php';

if (!isset($_SESSION['prijavljen'])) {
    header("Location: prijava.php");
}


function novi_korisnik($ime, $prezime, $korisnicko, $email, $lozinka, $slika, $tip){

  $insertNovi = "INSERT INTO korisnik (korisnik_id, tip_korisnika_id, korisnicko_ime, lozinka, ime, prezime, email, slika) VALUES (default, '" . $tip . "', '" . $korisnicko . "', '" . $lozinka  . "', '" . $ime . "', '" . $prezime . "', '" . $email . "', '" . $slika . "')";
  $rsInsert = izvrsiUpit($insertNovi);

  echo "Uspjesno ste kreirali korisnika!";

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="style.css">
  <title>Admin: Novi korisnik</title>
</head>
<body>

<header>
<nav>

<?php
  include 'navigacija.php';
?>

</nav>

</header>

<main>


<?php 

if(isset($_POST['submit'])){

  $ime = $_POST['ime'];
  $prezime = $_POST['prezime'];
  $korisnicko = $_POST['korisnicko'];
  $email = $_POST['email'];
  $lozinka = $_POST['lozinka'];
  $slika = $_POST['slika'];
  $tip = $_POST['vrste'];

  novi_korisnik($ime, $prezime, $korisnicko, $email, $lozinka, $slika, $tip);
  
}

?>

<form class="form" method="post" action="">

<label for="ime">Ime: </label>
<input type="text" class="ime" name="ime" id="ime" >

<label for="prezime">Prezime: </label>
<input type="text" class="prezime" name="prezime" id="prezime">

<label for="email">Email: </label>
<input type="text" class="email" name="email" id="email">

<label for="korisnicko">Korisnicko ime: </label>
<input type="text" class="korisnicko" name="korisnicko" id="korisnicko">

<label for="lozinka">Lozinka: </label>
<input type="lozinka" class="lozinka" name="lozinka" id="lozinka">

<label for="slika">Slika: </label>
<input type="slika" class="slika" name="slika" id="slika">

<select name="vrste">
  <option value="1">Administrator</option>
  <option value="2">Moderator</option>
  <option value="3">Obični korisnik</option>
</select>

<input type="submit" class="submit" id="submit" name="submit" value="Kreiraj korisnika">
</form>



</main>

</body>
</html>
