<?php

session_start();

include_once 'baza.php';

if (!isset($_SESSION['prijavljen'])) {
    header("prijava.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="autor" content="Dario Sakic" />
  <meta name="datum" content="kolovoz, 2018." />
  <meta name="kolegij" content="Izrada Web Aplikacija - IWA">
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="style.css">
	<title>Registrirani: Forma prijave izbora</title>
</head>
<body>

	<main>

	<?php

include "registrirani-forma-prijave-izbora.php";

?>
	</main>

</body>
</html>
