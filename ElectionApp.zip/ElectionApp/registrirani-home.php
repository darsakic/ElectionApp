<?php

session_start();

include_once 'baza.php';

if (!isset($_SESSION['prijavljen'])) {
    header("Location: prijava.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="autor" content="Dario Sakic" />
  <meta name="datum" content="kolovoz, 2018." />
  <meta name="kolegij" content="Izrada Web Aplikacija - IWA">
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="style.css">
	<title>Registrirani: Home</title>
</head>
<body>

	<header>

		<nav>

<?php
include 'navigacija.php';
?>

		</nav>

	</header>

	<main>

	<?php

include "registrirani-izbori-prikaz.php";
include "registrirani-kandidature.php";
include "registrirani-detalji-izbora.php";
include "registrirani-povuci-kandidaturu.php";

?>

	</main>

</body>
</html>
