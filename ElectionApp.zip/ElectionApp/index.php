<?php

include 'baza.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="autor" content="Dario Sakic" />
  <meta name="datum" content="kolovoz, 2018." />
  <meta name="kolegij" content="Izrada Web Aplikacija - IWA">
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="style.css">
	<title>Home</title>
</head>
<body>

	<header>

		<nav>

			<?php
				include 'navigacija.php'
			?>

		</nav>

	</header>

	<main>

		<?php

        include "neregistrirani-izborna-mjesta-prikaz.php";
        include "neregistrirani-zavrseni-izbori-prikaz.php";
        include "neregistrirani-pobjednici-prikaz.php";

?>

	</main>

</body>
</html>