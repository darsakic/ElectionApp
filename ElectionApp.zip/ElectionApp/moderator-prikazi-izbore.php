<?php

$sqlizbori = "SELECT * FROM izborno_mjesto m, izbor i WHERE m.izborno_mjesto_id = i.izborno_mjesto_id AND m.moderator_id = '" . $_SESSION['id_korisnika'] . "' ORDER BY i.datum_vrijeme_zavrsetka DESC";
$sqlresult = izvrsiUpit($sqlizbori);

echo "<table>";
echo "<h2>Popis kreiranih izbora</h2>";
echo "<th>Naziv (klik na naziv za ažuriranje)</th>";
echo "<th>Opis (klik na opis za odabir pobjednika)</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $izbori = array();
    $izbori[] = $row;

    foreach ($izbori as $data) {

        echo "<tr>";
        echo "<td><a href='moderator-home.php?izbor_id_azuriraj=" . $data['izbor_id'] . "'>" . $data['naziv'] . "</a></td>";
        echo "<td><a href='moderator-home.php?izbor_id_pobijedio=" . $data['izbor_id'] . "'>" . $data['opis'] . "</a></td>";
        echo "<td><a href='moderator-home.php?izbor_id=" . $data['izbor_id'] . "'>Kandidati</a></td>";
        echo "</tr>";

    }
}

echo "</table>";
