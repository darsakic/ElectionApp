<?php

function prikaz_detalja($izbor_id)
{
    $sqlizbor = "SELECT * FROM izborno_mjesto i, izbor r WHERE i.izborno_mjesto_id = r.izborno_mjesto_id AND r.datum_vrijeme_zavrsetka > CURRENT_TIMESTAMP() AND r.izbor_id = '" . $izbor_id . "' ORDER BY  r.datum_vrijeme_zavrsetka DESC";
    $sqlresult = izvrsiUpit($sqlizbor);

    echo "<table >";
    echo "<h2>O izboru</h2>";
    echo "<th>Naziv</th>";
    echo "<th>Datum i vrijeme početka</th>";
    echo "<th>Datum i vrijeme završetka</th>";
    echo "<th>Opis</th>";

    while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
        $izbor = array();
        $izbor[] = $row;

        foreach ($izbor as $data) {

            echo "<tr>";
            echo "<td>" . $data['naziv'] . "</td>";
            echo "<td>" . str_replace("-", ".", $data['datum_vrijeme_pocetka']) . "</td>";
            echo "<td>" . str_replace("-", ".", $data['datum_vrijeme_zavrsetka']) . "</td>";
            echo "<td>" . $data['opis'] . "</td>";
            echo "<td><a href='registrirani-prijava-izbora.php?korisnik_id=" . $_SESSION['id_korisnika'] . "&izbor_id=" . $izbor_id . "'>Kandidiraj se</a></td>";
            echo "</tr>";
        }
    }

    $sqlkandidati = "SELECT k.korisnik_id, k.ime, k.prezime, i.naziv, t.kandidat_id FROM korisnik k, kandidat t, izbor i WHERE k.korisnik_id = t.korisnik_id AND t.izbor_id = i.izbor_id AND t.status<>'O' AND i.izbor_id = '" . $izbor_id . "'";
    $sqlresult_kandidati = izvrsiUpit($sqlkandidati);

    echo "<table>";
    echo "<h2>Kandidati</h2>";
    echo "<th>Ime</th>";
    echo "<th>Prezime</th>";

    while (($row = mysqli_fetch_array($sqlresult_kandidati, MYSQLI_ASSOC)) != false) {
        $kandidati = array();
        $kandidati[] = $row;

        foreach ($kandidati as $data) {

            echo "<tr>";
            echo "<td>" . $data['ime'] . "</td>";
            echo "<td>" . $data['prezime'] . "</td>";
            echo "<td><a href='registrirani-home.php?izbor_id=" . $izbor_id . "&korisnik_id=" . $_SESSION['id_korisnika'] . "&kandidat_id=" . $data['kandidat_id'] . "'>Daj svoj glas</a></td>";
            echo "</tr>";

        }
    }

}

if (isset($_GET['izbor_id'])) {
    $izbor_id = $_GET['izbor_id'];
    prikaz_detalja($izbor_id);

    include "registrirani-izbori-glasovanje.php";
}
