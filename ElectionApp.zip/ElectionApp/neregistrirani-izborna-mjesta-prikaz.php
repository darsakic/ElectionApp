<?php
$sqlmjesta = "SELECT * FROM izborno_mjesto";
$sqlresult = izvrsiUpit($sqlmjesta);

echo "<table>";
echo "<th>Naziv</th>";
echo "<th>Opis</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $izbornomjesto = array();
    $izbornomjesto[] = $row;

    foreach ($izbornomjesto as $data) {

        echo "<tr>";
        echo "<td>" . $data['naziv'] . "</td>";
        echo "<td>" . $data['opis'] . "</td>";
        echo "<td><a href='index.php?izborno_mjesto_id=" . $data['izborno_mjesto_id'] . "'>Završeni izbori</a></td>";
        echo "</tr>";

    }
}

echo "</table>";
