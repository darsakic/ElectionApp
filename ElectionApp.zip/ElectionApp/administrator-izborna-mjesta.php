<?php

session_start();

include 'baza.php';

if (!isset($_SESSION['prijavljen'])) {
    header("Location: prijava.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="style.css">
  <title>Home</title>
</head>
<body>

<header>
<nav>

<?php
include 'navigacija.php';
?>


</nav>

</header>

<main>

<?php
$sqlmjesta = "SELECT * FROM izborno_mjesto";
$sqlresult = izvrsiUpit($sqlmjesta);

echo "<table class='aktivni-izbori'>";
echo "<h2>Izborna mjesta</h2>";
echo "<th>Naziv</th>";
echo "<th>Opis</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $izbori = array();
    $izbori[] = $row;

    foreach ($izbori as $data) {
        echo "<tr>";
        echo "<td>" . $data['naziv'] . "</td>";
        echo "<td>" . $data['opis'] . "</td>";
        echo "<td><a href='administrator-izborna-mjesta.php?promjena=" . $data['izborno_mjesto_id'] . "'>Promjeni naziv i opis</a></td>";

    }
}

echo "</table>";

echo "<form class='novo-mjesto' action='administrator-izborna-mjesta-novo.php'>";
echo "<input  type='submit' value='Dodaj novo'>";
echo "</form>";

function prikazi_formu($id_izborno_mjesto)
{

    $sqlizbornamjesta = "SELECT * FROM izborno_mjesto WHERE izborno_mjesto_id LIKE '" . $id_izborno_mjesto . "'";
    $sqlresult = izvrsiUpit($sqlizbornamjesta);

    echo '<form class="form" method="post" action=""';

    while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
        $izbornaMjesta = array();
        $izbornaMjesta[] = $row;

        foreach ($izbornaMjesta as $data) {

            echo '<label for="naziv">Naziv: </label>';
            echo '<input type="naziv" value="' . $data['naziv'] . '" class="naziv" name="naziv" id="naziv">';

            echo '<label for="opis">Opis: </label>';
            echo '<input type="opis" value="' . $data['opis'] . '" class="opis" name="opis" id="opis">';

        }
    }

    echo '<input type="submit" class="submit" id="submit" name="submit" value="Potvrdi">';
    echo '</form>';
}

if (isset($_GET['promjena'])) {

    prikazi_formu($_GET['promjena']);

    if (isset($_POST['submit'])) {

        $sqlmjesto = "UPDATE izborno_mjesto SET naziv = '" . $_POST['naziv'] . "', opis = '" . $_POST['opis'] . "'  WHERE izborno_mjesto_id = '" . $_GET['promjena'] . "'";
        $sqlresult = izvrsiUpit($sqlmjesto);

        echo "Opis i naziv promjenjeni!";
        header("Location: administrator-izborna-mjesta.php");
    }
}

?>

</main>

</body>
</html>
