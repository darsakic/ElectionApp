<?php

function prikazi_kandidate($izbor_id)
{
    $sqlkandidat = "SELECT korisnik.ime, korisnik.prezime, COUNT(*)/(SELECT COUNT(*) AS ukupno FROM korisnik, kandidat, glas WHERE korisnik.korisnik_id=glas.korisnik_id AND glas.kandidat_id=kandidat.kandidat_id AND kandidat.izbor_id='" . $izbor_id . "')*100 AS postotak FROM korisnik, kandidat, glas WHERE korisnik.korisnik_id=glas.korisnik_id AND glas.kandidat_id=kandidat.kandidat_id AND kandidat.izbor_id= '" . $izbor_id . "' AND kandidat.status<>'O' GROUP BY kandidat.korisnik_id";
    $sqlresult = izvrsiUpit($sqlkandidat);

    echo "<table>";
    echo "<h2>Kandidati odabrnog izbora</h2>";
    echo "<th>Ime</th>";
    echo "<th>Prezime</th>";
    echo "<th>Glasovi</th>";

    while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
        $izbori = array();
        $izbori[] = $row;

        foreach ($izbori as $data) {

            echo "<tr>";
            echo "<td>" . $data['ime'] . "</td>";
            echo "<td>" . $data['prezime'] . "</td>";
            echo "<td>" . $data['postotak'] . "</td>";
            echo "</tr>";
        }
    }
    
    echo "</table>";
}

if (isset($_GET['izbor_id'])) {
    prikazi_kandidate($_GET['izbor_id']);
}
