<?php

$sqlizbor = "SELECT * FROM izborno_mjesto i, izbor r WHERE i.izborno_mjesto_id = r.izborno_mjesto_id AND r.datum_vrijeme_zavrsetka > CURRENT_TIMESTAMP() ORDER BY r.datum_vrijeme_zavrsetka DESC";
$sqlresult = izvrsiUpit($sqlizbor);

echo "<table>";
echo "<h2>Trenutno aktivni izbori</h2>";
echo "<th>Naziv</th>";
echo "<th>Opis</th>";

while (($row = mysqli_fetch_array($sqlresult, MYSQLI_ASSOC)) != false) {
    $izbori = array();
    $izbori[] = $row;

    foreach ($izbori as $data) {

        echo "<tr>";
        echo "<td>" . $data['naziv'] . "</td>";
        echo "<td>" . $data['opis'] . "</td>";
        echo "<td><a href='registrirani-home.php?izbor_id=" . $data['izbor_id'] . "'>O Izboru</a></td>";
        echo "</tr>";

    }
}

echo "</table>";
