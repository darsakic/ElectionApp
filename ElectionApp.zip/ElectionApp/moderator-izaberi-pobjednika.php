<?php

function odabir_pobjednika($izbor_id)
{ 
    $sqlpobjednik = "SELECT korisnik.korisnik_id, korisnik.ime, korisnik.prezime, COUNT(*)/(SELECT COUNT(*) AS ukupno FROM korisnik, kandidat, glas WHERE korisnik.korisnik_id=glas.korisnik_id AND glas.kandidat_id=kandidat.kandidat_id AND kandidat.izbor_id='" . $izbor_id . "')*100 AS postotak FROM korisnik, kandidat, glas WHERE korisnik.korisnik_id=glas.korisnik_id AND glas.kandidat_id=kandidat.kandidat_id AND kandidat.izbor_id= '" . $izbor_id . "' AND kandidat.status<>'O' GROUP BY kandidat.korisnik_id";
    $sqlresult = izvrsiUpit($sqlpobjednik);

    foreach ($sqlresult as $row) {

        $pobjednici = array();

        foreach ($row as $key => $value) {

            $pobjednici[$key] = $value;

        }

        if ($pobjednici['postotak'] > 50) {

            $sqlpobjednik = "UPDATE kandidat SET status = 'P' WHERE korisnik_id = '" . $pobjednici['korisnik_id'] . "' AND izbor_id = '" . $izbor_id . "'";
            $sqlresult_pobjednik = izvrsiUpit($sqlpobjednik);

            echo "Uspjesno ste odabrali pobjednika!";


        } else {

            $sqlmjesto = "SELECT * FROM izbor  WHERE izbor_id = '" . $izbor_id . "'";
            $sqlreslut_mjesto = izvrsiUpit($sqlmjesto);

            if (mysqli_num_rows($sqlreslut_mjesto) > 0) {
                while ($row = $sqlreslut_mjesto->fetch_assoc()) {
                    $izborno_mjesto_id = $row["izborno_mjesto_id"];
                }
            }

            $sqldelete = "DELETE FROM izbor WHERE izbor_id = '" . $izbor_id . "'";
            $sqlresult_delete = izvrsiUpit($sqldelete);

            header("Location: moderator-izborna-mjesta.php?izborno_mjesto_id='" . $izborno_mjesto_id . "'");
        }
    }

}
