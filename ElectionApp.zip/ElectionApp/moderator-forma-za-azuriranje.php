<?php

function prikazi_formu_za_azuriranje($izbor_id)
{

    echo '<form class="form" method="post" action=""';

    echo '<label for="naziv">Novi naziv: </label>';
    echo '<input type="pozicija" class="naziv" name="naziv" id="naziv">';

    echo '<input type="submit" class="submit" id="submit" name="submit" value="Potvrdi">';
    echo '</form>';

    include "moderator-azuriranje-izbora.php";

}


if (isset($_GET['izbor_id_azuriraj'])) {
  prikazi_formu_za_azuriranje($_GET['izbor_id_azuriraj']);
}


?>