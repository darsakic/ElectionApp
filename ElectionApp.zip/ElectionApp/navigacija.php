<?php

echo "<ul>";

if (!isset($_SESSION['prijavljen'])) {
    echo "<li><a href='index.php'>Početna</a></li>";
    echo "<li><a href='o_autoru.html'>O autoru</a></li>";
    echo "<li><a href='prijava.php'>Prijava</a></li>";
} else {
    switch ($_SESSION['tip_korisnika']) {
        case 1:
            echo '<li><a href="index.php">Opcije neregistriranog</a></li>';
            echo '<li><a href="registrirani-home.php">Opcije registriranog</a></li>';
            echo '<li><a href="moderator-home.php">Opcije moderatora</a></li>';
            echo '<li><a href="administrator-novi-korisnik.php">Novi korisnik</a></li>';
            echo '<li><a href="administrator-izborna-mjesta.php">Izborna mjesta</a></li>';
            echo '<li><a href="administrator-prikaz-izbora.php">Popis svih izbora</a></li>';
            echo '<li><a href="odjava.php">Odjava</a></li>';
            break;
        case 2:
            echo '<li><a href="index.php">Opcije neregistriranog</a></li>';
            echo '<li><a href="registrirani-home.php">Opcije registriranog</a></li>';
            echo '<li><a href="moderator-home.php">Kreirani izbori</a></li>';
            echo '<li><a href="moderator-izborna-mjesta.php">Izborna mjesta</a></li>';
            echo '<li><a href="odjava.php">Odjava</a></li>';
            break;
        case 3:
            echo '<li><a href="index.php">Opcije neregistriranog</a></li>';
            echo '<li><a href="registrirani-home.php">Home</a></li>';
            echo '<li><a href="odjava.php">Log out</a></li>';
            break;
        default:
            break;
    }
}

echo "</ul>";

?>