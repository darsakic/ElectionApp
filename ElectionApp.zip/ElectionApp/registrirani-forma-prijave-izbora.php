<?php

function prijava_izbora($korisnik_id, $izbor_id)
{
    $sqlstatus = "SELECT * FROM kandidat WHERE korisnik_id = '" . $korisnik_id . "' AND izbor_id = '" . $izbor_id . "' AND status = 'K'";
    $sqlresult = izvrsiUpit($sqlstatus);

    if (mysqli_num_rows($sqlresult) != null) {
        echo "Ne možete se kandidarati dva put za isti izbor!";
        echo " ";
        echo "Za 2 sec će te biti preusmjereni nazad...";

        header('Refresh: 2; URL=prijava.php');
    } else {
        echo '<form class="form" method="post" action=""';

        echo '<label for="cv">Životopis: </label>';
        echo '<textarea rows="2" cols="20" class="cv" name="cv" id="cv"></textarea>';

        echo '<label for="url">URL: </label>';
        echo '<input type="text" class="url" name="url" id="url">';

        echo '<input type="submit" class="submit" id="submit" name="submit" value="Prijavi se">';
        echo '</form>';
    }
}

if(isset($_GET['korisnik_id']) && isset($_GET['izbor_id'])){
  $korisnik_id = $_GET['korisnik_id'];
  $izbor_id = $_GET['izbor_id'];
  
  prijava_izbora($korisnik_id, $izbor_id);

  include "registrirani-prijava-kandidata.php";
}