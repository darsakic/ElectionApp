<?php

if (isset($_GET['izborno_mjesto_id'])) {
    echo '<form class="form-mjesta" method="post" action=""';

    echo '<label for="naziv">Naziv: </label>';
    echo '<input type="text" class="naziv" name="naziv" id="naziv">';

    echo '<label for="pocetak">Datum i vrijeme početka: </label>';
    echo '<input type="text" class="pocetak" name="pocetak" id="pocetak" placeholder="dd.mm.yyyy hh:mm:ss">';

    echo '<label for="opis">Opis izbora: </label>';
    echo '<input type="text" class="opis" name="opis" id="opis">';

    echo '<input type="submit" class="submit" id="submit" name="submit" value="Kreiraj izbor">';
    echo '</form>';
}