<?php

if (isset($_POST['submit'])) {

    $sqlinsert = "INSERT INTO kandidat (kandidat_id, korisnik_id, izbor_id, zivotopis, video, status) VALUES (default, '" . $korisnik_id . "', '" . $izbor_id . "', '" . $_POST['cv'] . "', '" . $_POST['url'] . "', 'K')";
    $sqlresult = izvrsiUpit($sqlinsert);

    echo "Kandidatura uspješno izvršena!";
    echo " ";
    echo "Za 2 sec će te biti preusmjereni nazad...";

    header('Refresh: 2; URL=prijava.php');
}
