<?php

session_start();
include 'baza.php';


function korisnik_tip($ktip){
    if ($ktip === '3') {
        header("Location: registrirani-home.php");
    } 
    
    if ($ktip === '2') {
        header("Location: moderator-home.php");
    } 
    
    if ($ktip === '1') {
        header("Location: administrator-home.php");
    }
}


if (isset($_SESSION['prijavljen']) && $_SESSION['prijavljen'] === 'TRUE') {
    korisnik_tip($_SESSION['tip_korisnika']);
} else {

    if (isset($_POST["submit"])) {

        $sqlprijava = "SELECT * FROM korisnik WHERE korisnicko_ime = '" . $_POST['username'] . "' AND lozinka = '" . $_POST['password'] . "' ";
        $sqlresult = izvrsiUpit($sqlprijava);

        if (mysqli_num_rows($sqlresult) > 0) {
            while ($row = $sqlresult->fetch_assoc()) {
                $id = $row["korisnik_id"];
                $tip = $row["tip_korisnika_id"];
                $kime = $row["korisnicko_ime"];
            }

            $_SESSION['prijavljen'] = "TRUE";
            $_SESSION['id_korisnika'] = $id;
            $_SESSION['tip_korisnika'] = $tip;
            $_SESSION['korisnicko_ime'] = $kime;

            korisnik_tip($_SESSION['tip_korisnika']);
        } else {
            echo "Unešeni pogrešni podaci! Pokušajte ponovno";
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="autor" content="Dario Sakic" />
  <meta name="datum" content="kolovoz, 2018." />
  <meta name="kolegij" content="Izrada Web Aplikacija - IWA">
  <meta charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>Prijava</title>
</head>
<body>

<header>

<nav>
  <ul>
    <li><a href="index.php">Početna</a></li>
    <li><a href="o_autoru.html">O Autoru</a></li>
    <li><a href="prijava.php">Prijava</a></li>
  </ul>
</nav>
</header>

<h3 class="prijava-title">Prijavi se</h3>

<form class="form" method="post" action="">

    <label for="username">Korisnicko ime: </label>
    <input type="text" class="username" name="username" id="username" style="margin-right: 20px;">

    <label for="password">Lozinka: </label>
    <input type="password" class="password" name="password" id="password" autocomplete="off">

    <input type="submit" class="submit" id="submit" name="submit" value="Prijavi se">
</form>

</body>
</html>
