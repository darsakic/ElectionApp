<?php

function azuriranje_izbora($naziv, $izbor_id)
{
    $sqlnaziv = "UPDATE izbor SET naziv = '" . $naziv . "' WHERE izbor_id = '" . $izbor_id . "'";
    $sqlrezult = izvrsiUpit($sqlnaziv);

    echo "Novi naziv izbora kreiran!";
    echo " ";

    header('Refresh: 1; URL=moderator-home.php');

}

if (isset($_POST['submit'])) {
    azuriranje_izbora($_POST['naziv'], $izbor_id);
}
