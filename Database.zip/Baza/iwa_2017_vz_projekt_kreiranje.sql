-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema iwa_2017_vz_projekt
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema iwa_2017_vz_projekt
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `iwa_2017_vz_projekt` DEFAULT CHARACTER SET utf8 ;
USE `iwa_2017_vz_projekt` ;

-- -----------------------------------------------------
-- Table `iwa_2017_vz_projekt`.`tip_korisnika`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `iwa_2017_vz_projekt`.`tip_korisnika` (
  `tip_korisnika_id` INT NOT NULL AUTO_INCREMENT,
  `naziv` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`tip_korisnika_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `iwa_2017_vz_projekt`.`korisnik`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `iwa_2017_vz_projekt`.`korisnik` (
  `korisnik_id` INT NOT NULL AUTO_INCREMENT,
  `tip_korisnika_id` INT NOT NULL,
  `korisnicko_ime` VARCHAR(50) NOT NULL,
  `lozinka` VARCHAR(50) NOT NULL,
  `ime` VARCHAR(50) NOT NULL,
  `prezime` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `slika` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`korisnik_id`),
  INDEX `fk_korisnik_tip_korisnika_idx` (`tip_korisnika_id` ASC),
  CONSTRAINT `fk_korisnik_tip_korisnika`
    FOREIGN KEY (`tip_korisnika_id`)
    REFERENCES `iwa_2017_vz_projekt`.`tip_korisnika` (`tip_korisnika_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `iwa_2017_vz_projekt`.`izborno_mjesto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `iwa_2017_vz_projekt`.`izborno_mjesto` (
  `izborno_mjesto_id` INT NOT NULL AUTO_INCREMENT,
  `moderator_id` INT NOT NULL,
  `naziv` VARCHAR(50) NOT NULL,
  `opis` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`izborno_mjesto_id`),
  INDEX `fk_mjesto_korisnik1_idx` (`moderator_id` ASC),
  CONSTRAINT `fk_mjesto_korisnik1`
    FOREIGN KEY (`moderator_id`)
    REFERENCES `iwa_2017_vz_projekt`.`korisnik` (`korisnik_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `iwa_2017_vz_projekt`.`izbor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `iwa_2017_vz_projekt`.`izbor` (
  `izbor_id` INT NOT NULL AUTO_INCREMENT,
  `izborno_mjesto_id` INT NOT NULL,
  `naziv` VARCHAR(50) NOT NULL,
  `datum_vrijeme_pocetka` DATETIME NOT NULL,
  `datum_vrijeme_zavrsetka` DATETIME NOT NULL,
  `opis` TEXT NULL,
  PRIMARY KEY (`izbor_id`),
  INDEX `fk_izbori_mjesto1_idx` (`izborno_mjesto_id` ASC),
  CONSTRAINT `fk_izbori_mjesto1`
    FOREIGN KEY (`izborno_mjesto_id`)
    REFERENCES `iwa_2017_vz_projekt`.`izborno_mjesto` (`izborno_mjesto_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `iwa_2017_vz_projekt`.`kandidat`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `iwa_2017_vz_projekt`.`kandidat` (
  `kandidat_id` INT NOT NULL AUTO_INCREMENT,
  `korisnik_id` INT NOT NULL,
  `izbor_id` INT NOT NULL,
  `zivotopis` TEXT NOT NULL,
  `video` TEXT NOT NULL,
  `status` CHAR(1) NOT NULL,
  INDEX `fk_korisnik_has_izbori_izbori1_idx` (`izbor_id` ASC),
  INDEX `fk_korisnik_has_izbori_korisnik1_idx` (`korisnik_id` ASC),
  PRIMARY KEY (`kandidat_id`),
  CONSTRAINT `fk_korisnik_has_izbori_korisnik1`
    FOREIGN KEY (`korisnik_id`)
    REFERENCES `iwa_2017_vz_projekt`.`korisnik` (`korisnik_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_korisnik_has_izbori_izbori1`
    FOREIGN KEY (`izbor_id`)
    REFERENCES `iwa_2017_vz_projekt`.`izbor` (`izbor_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `iwa_2017_vz_projekt`.`glas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `iwa_2017_vz_projekt`.`glas` (
  `korisnik_id` INT NOT NULL,
  `kandidat_id` INT NOT NULL,
  INDEX `fk_korisnik_has_kandidat_kandidat1_idx` (`kandidat_id` ASC),
  INDEX `fk_korisnik_has_kandidat_korisnik1_idx` (`korisnik_id` ASC),
  CONSTRAINT `fk_korisnik_has_kandidat_korisnik1`
    FOREIGN KEY (`korisnik_id`)
    REFERENCES `iwa_2017_vz_projekt`.`korisnik` (`korisnik_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_korisnik_has_kandidat_kandidat1`
    FOREIGN KEY (`kandidat_id`)
    REFERENCES `iwa_2017_vz_projekt`.`kandidat` (`kandidat_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

CREATE USER 'iwa_20177'@'localhost' IDENTIFIED BY 'foi2017';

GRANT SELECT, INSERT, TRIGGER, UPDATE, DELETE ON TABLE `iwa_2017_vz_projekt`.* TO 'iwa_2017'@'localhost';

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
