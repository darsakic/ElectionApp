#odabir svih korisnika
SELECT * FROM korisnik;

#opci podaci izbornog mjesta 1
SELECT naziv, opis FROM izborno_mjesto WHERE izborno_mjesto_id = 1;

#odabir svih moderatora
SELECT * FROM korisnik WHERE tip_korisnika_id = 2;

#odabir svih izbora za izborno mjesto 1
SELECT * FROM izbor WHERE izborno_mjesto_id = 1;

#odabir svih zatvorenih izbora za izborno mjesto 1 sortirano po datumu i vremenu zavrsetka
SELECT * FROM izborno_mjesto i, izbor r
WHERE i.izborno_mjesto_id = r.izborno_mjesto_id AND i.izborno_mjesto_id = 1
AND r.datum_vrijeme_zavrsetka < CURRENT_TIMESTAMP() ORDER BY r.datum_vrijeme_zavrsetka DESC;

#odabir izbora filtriran i sortiran na bazi izbornog mjesta i izbora
SELECT izbor.naziv, izborno_mjesto.naziv FROM izborno_mjesto, izbor
WHERE izborno_mjesto.izborno_mjesto_id = izbor.izborno_mjesto_id
AND izbor.naziv = 'Župan' ORDER BY izborno_mjesto.naziv;

#podaci kandidata koji je pobijedio na izboru 1
SELECT * FROM korisnik k, kandidat t
WHERE k.korisnik_id=t.korisnik_id AND t.izbor_id = 1 AND t.status = 'P';

#odabir svih izbora koje smije uređivati moderator 2 sortirano po datumu i vremenu zavrsetka
SELECT * FROM izborno_mjesto m, izbor i
WHERE m.izborno_mjesto_id = i.izborno_mjesto_id
AND m.moderator_id = 2 ORDER BY i.datum_vrijeme_zavrsetka DESC;

#odabir svih izbora na koje se je kandidirao korisnik 3
SELECT k.ime, k.prezime, i.naziv, i.opis FROM korisnik k, kandidat t, izbor i
WHERE k.korisnik_id = t.korisnik_id AND t.izbor_id = i.izbor_id
AND t.status<>'O' AND t.korisnik_id = 3;

#odabir svih kandidata na izboru 1
SELECT k.ime, k.prezime, i.naziv FROM korisnik k, kandidat t, izbor i
WHERE k.korisnik_id = t.korisnik_id AND t.izbor_id = i.izbor_id
AND t.status<>'O' AND i.izbor_id = 1;

#odabir prijavljenih kandidata na izboru 5 zajedno sa postotkom glasova
SELECT korisnik.ime, korisnik.prezime,
COUNT(*)/(SELECT COUNT(*) AS ukupno FROM korisnik, kandidat, glas
WHERE korisnik.korisnik_id=glas.korisnik_id AND glas.kandidat_id=kandidat.kandidat_id
AND kandidat.izbor_id=5)*100 AS postotak
FROM korisnik, kandidat, glas
WHERE korisnik.korisnik_id=glas.korisnik_id
AND glas.kandidat_id=kandidat.kandidat_id AND kandidat.izbor_id=5
AND kandidat.status<>'O'
GROUP BY kandidat.korisnik_id;

#broj glasova za kandidate 1 na izboru 1
SELECT korisnik.ime, korisnik.prezime, COUNT(*) AS broj_glasova
FROM korisnik, kandidat, glas
WHERE korisnik.korisnik_id=glas.korisnik_id
AND glas.kandidat_id=kandidat.kandidat_id AND kandidat.izbor_id=1
GROUP BY kandidat.korisnik_id;

#rang lista korisnika za izbore koje je kreirao moderator 2
#s najvecim brojem kandidatura odabranog razdoblja, npr. od 01.01.2018. u 00:00:00 do 30.04.2018. u 00:00:00
SELECT COUNT(*) AS rang_lista, k.ime, k.prezime FROM korisnik k, kandidat t, izbor i
WHERE k.korisnik_id = t.korisnik_id AND t.izbor_id=i.izbor_id AND t.status<>'O'
AND i.datum_vrijeme_zavrsetka BETWEEN '2018-01-01 00:00:00' AND '2018-04-30 00:00:00'
AND i.izborno_mjesto_id IN (SELECT izborno_mjesto_id FROM izborno_mjesto WHERE moderator_id = 2)
GROUP BY t.korisnik_id ORDER BY rang_lista DESC;
